/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./public/**/*.{html,js}"
  ],
  theme: {
    colors: {
      black: 'var(--black)',
      white: 'var(--white)',
      orange: 'var(--orange)',
    },
    fontFamily:{
        'Dancing-Scripts': 'var(--font-Dancing-Scripts)',
        'Lato': 'var(--font-Lato)',
        'Poppins': 'var(--font-Poppins)',
    },
    extend: {
      height:{
        'aside': 'calc(100vh-64px)'
      }
    },
  },
  plugins: [],
}

